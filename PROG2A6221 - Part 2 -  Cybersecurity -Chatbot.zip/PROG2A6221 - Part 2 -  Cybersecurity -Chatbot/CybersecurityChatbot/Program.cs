﻿using System;
using System.Collections.Generic;
using System.Media;
using System.Threading;

namespace CybersecurityChatbot
{
    class Program
    {
        // Path to the greeting audio file
        private const string SoundLocation = "GreetingAudio.wav";

        // Variables to store user's name and interest
        static string userName = "";
        static string userInterest = "";

        // Dictionary mapping keywords to responses
        static Dictionary<string, string> keywordResponses = new()
        {
            { "password", "Make sure to use strong, unique passwords for each account. Avoid using personal details." },
            { "scam", "Watch out for online scams. Don’t click links from unknown sources or respond to suspicious emails." },
            { "privacy", "Check your privacy settings regularly and avoid oversharing personal information online." }
        };

        // Dictionary containing random responses to specific topics
        static Dictionary<string, List<string>> randomResponses = new()
        {
            { "phishing", new List<string>
                {
                    "Be cautious of emails asking for personal information.",
                    "Phishing emails often look official—double-check URLs and sender addresses.",
                    "Never click on suspicious links or download attachments from unknown sources."
                }
            }
        };

        static void Main(string[] args)
        {
            Console.Title = "Cybersecurity Awareness Assistant"; // Set console window title
            PlayVoiceGreeting();     // Optional voice greeting
            DisplayAsciiArt();       // Show ASCII banner
            GreetUser();             // Ask user for their name and greet them
            HandleUserInput();       // Begin interactive loop

            Console.WriteLine($"\nThanks for chatting with me, {userName}. Stay safe online! 👋");
        }

        /// <summary>
        /// Plays an audio greeting from a WAV file.
        /// </summary>
        static void PlayVoiceGreeting()
        {
            try
            {
                SoundPlayer player = new(SoundLocation);
                player.PlaySync();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Voice greeting could not be played: " + ex.Message);
                Console.ResetColor();
            }
        }

        /// <summary>
        /// Displays stylized ASCII art as a banner.
        /// </summary>
        static void DisplayAsciiArt()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
  ____  __  __    _    ____ _____ _____     ____   ___ _____ 
 / ___||  \/  |  / \  | __ )_   _| ____|   | __ ) / _ \_   _|
 \___ \| |\/| | / _ \ |  _ \ | | |  _|     |  _ \| | | || |  
  ___) | |  | |/ ___ \| |_) || | | |___    | |_) | |_| || |  
 |____/|_|  |_/_/   \_\____/ |_| |_____|   |____/ \___/ |_|  
");
            Console.ResetColor();
        }

        /// <summary>
        /// Prompts user for their name and welcomes them.
        /// </summary>
        static void GreetUser()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\n What's your name? ");
            Console.ResetColor();

            userName = Console.ReadLine();

            Console.ForegroundColor = ConsoleColor.Green;
            TypeEffect($"\nWelcome, {userName}! I'm your Cybersecurity Awareness Assistant.");
            Console.ResetColor();
        }

        /// <summary>
        /// Main interaction loop for accepting and responding to user input.
        /// </summary>
        static void HandleUserInput()
        {
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("\n Ask me a cybersecurity question (or type 'exit'): ");
                Console.ResetColor();

                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" Please enter something. I can’t help if I don’t understand.");
                    Console.ResetColor();
                    continue;
                }

                if (input.ToLower() == "exit") break;

                RespondToUser(input);
            }
        }

        /// <summary>
        /// Processes user input and provides relevant responses.
        /// Includes sentiment detection, keyword matching, random advice, and memory recall.
        /// </summary>
        static void RespondToUser(string input)
        {
            input = input.ToLower(); // Normalize input
            Console.ForegroundColor = ConsoleColor.Cyan;

            // --- Help Command ---
            if (input.Contains("help"))
            {
                TypeEffect("Sure! I can help you with these topics:");
                TypeEffect(" Password Safety");
                TypeEffect(" Phishing Scams");
                TypeEffect(" Privacy Settings");
                TypeEffect(" Online Scams");
                TypeEffect(" Safe Browsing Tips");
                TypeEffect("\nJust type a question or topic you're curious about!");
                Console.ResetColor();
                return;
            }

            // --- Sentiment Detection ---
            if (input.Contains("worried") || input.Contains("scared") || input.Contains("frustrated"))
            {
                TypeEffect("It's okay to feel that way. Cybersecurity can be complex, but I'm here to help.");
                Console.ResetColor();
                return;
            }

            // --- Memory and Interest Tracking ---
            if (input.Contains("i'm interested in"))
            {
                int start = input.IndexOf("i'm interested in") + "i'm interested in".Length;
                userInterest = input.Substring(start).Trim();
                TypeEffect($"Great! I'll remember that you're interested in {userInterest}. It's a crucial part of staying safe online.");
                Console.ResetColor();
                return;
            }

            // --- Personalized Suggestion Based on Interest ---
            if (input.Contains("what should i do"))
            {
                if (!string.IsNullOrEmpty(userInterest))
                {
                    TypeEffect($"As someone interested in {userInterest}, you should regularly review and update your settings.");
                }
                else
                {
                    TypeEffect("Let me know what you're interested in, like 'I'm interested in privacy', and I’ll tailor tips for you.");
                }
                Console.ResetColor();
                return;
            }

            // --- Randomized Response Based on Topics ---
            foreach (var topic in randomResponses.Keys)
            {
                if (input.Contains(topic))
                {
                    var responses = randomResponses[topic];
                    Random rand = new();
                    TypeEffect(responses[rand.Next(responses.Count)]);
                    Console.ResetColor();
                    return;
                }
            }

            // --- Keyword-based Static Responses ---
            foreach (var keyword in keywordResponses.Keys)
            {
                if (input.Contains(keyword))
                {
                    TypeEffect(keywordResponses[keyword]);
                    Console.ResetColor();
                    return;
                }
            }

            // --- Simple Additional Intents ---
            if (input.Contains("hi there"))
                TypeEffect("I'm Smart Bot, I'm functioning as expected and ready to help!");
            else if (input.Contains("purpose"))
                TypeEffect("My purpose is to help you stay safe online by teaching you good cybersecurity practices.");
            else if (input.Contains("browsing"))
                TypeEffect("Use updated browsers, avoid suspicious websites, and enable safe browsing features.");
            else
                TypeEffect("I didn’t quite understand that. Could you rephrase your question or type 'help' to see what I can do?");

            Console.ResetColor();
        }


        /// <summary>
        /// Displays text as if it's being typed in real-time.
        /// </summary>
        /// <param name="message">Text to display</param>
        /// <param name="delay">Milliseconds to delay between characters</param>
        static void TypeEffect(string message, int delay = 30)
        {
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(delay);
            }
            Console.WriteLine();
        }
    }
}







//Reference List

//Date: 26 May 2025

//Author: Darsh Somayi

//Sources used to help code : 

//Troelsen, A. & Japikse, P., 2022. Pro C# 10 with .NET 6: Foundational Principles and Practices in Programming. 11th ed. New York: Apress.

//W3Schools, 2025. W3Schools Online Web Tutorials. [online] Available at: https://www.w3schools.com [Accessed 23 Apr. 2025].



