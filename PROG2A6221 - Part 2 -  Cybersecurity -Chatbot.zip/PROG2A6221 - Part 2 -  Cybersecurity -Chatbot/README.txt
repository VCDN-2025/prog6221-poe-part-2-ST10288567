﻿ Cybersecurity Awareness Chatbot (Console Application in C#)

This is a simple yet interactive **Cybersecurity Awareness Assistant** built using C#. It is designed to educate users about common cybersecurity threats and offer friendly, helpful guidance on how to stay safe online. The chatbot interacts via the console and features audio, ASCII art, smart keyword recognition, sentiment detection, personalized memory, and randomized tips.

---

 Features

- Audio Greeting: Welcomes users with a spoken WAV audio file.
- ASCII Banner: Displays a welcoming banner in ASCII art.
- Smart Input Recognition**: Understands and responds to keywords like "password", "privacy", "phishing", "scam", etc.
- Help Command: Type `help` to view a list of topics the bot can assist with.
-Random Tips: Provides varied responses to prevent repetitive answers on topics like phishing.
- Memory**: Remembers user interests and provides personalized recommendations.
- Sentiment Detection**: Recognizes words like “worried”, “frustrated”, and responds empathetically.
- Exit Anytime**: Type `exit` to end the conversation gracefully.

---

 📂 Project Structure

```plaintext
CybersecurityChatbot/
├── GreetingAudio.wav        # Optional greeting sound file
├── Program.cs               # Main chatbot logic
├── README.md                # Project overview and instructions








//Reference List

//Date: 26 May 2025

//Author: Darsh Somayi

//Sources used to help code : 

//Troelsen, A. & Japikse, P., 2022. Pro C# 10 with .NET 6: Foundational Principles and Practices in Programming. 11th ed. New York: Apress.

//W3Schools, 2025. W3Schools Online Web Tutorials. [online] Available at: https://www.w3schools.com [Accessed 23 Apr. 2025].



